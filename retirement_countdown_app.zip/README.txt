RETIREMENT COUNTDOWN

Your retirement date: June 9, 2027
Work schedule: Monday-Friday
The countdown excludes weekends and standard U.S. federal observed holidays.
Vacation dates can be added inside the app and are saved on the device.

IMPORTANT:
This is a small web app. To use it like an iPhone Home Screen app, the index.html file needs to be hosted at a web address (for example with a simple static hosting service). Then open that address in Safari and choose Share > Add to Home Screen.

The included holiday list is the standard federal observed holiday schedule for the relevant period. If your employer observes additional paid holidays, those can be added to the holiday list in index.html.
